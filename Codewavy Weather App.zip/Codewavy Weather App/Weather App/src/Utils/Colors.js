export const COLORS = {
    WHITE: '#fff',
    BLACK: '#000',
    YELLOW_COLOR: '#FFE142',
    ALERT: '#ED4F32'
}