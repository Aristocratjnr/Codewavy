export const FONTS = {
    POPPINS_REGULAR: 'Poppins-Regular',
    POPPINS_SEMIBOLD: 'Poppins-SemiBold',
    POPPINS_BOLD: 'Poppins-Bold'
}